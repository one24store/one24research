```
npm start
```
### This will start the server on localhost:3000
### Whenever any instance of the project opens/closes it up in a tab or window, the subsequent information will be displayed in the server's console

## What this does exactly ?
### Whenever someone opens the page, a random id ( between 0 and 10, inclusive ) is assigned to that user, and his joining message is displayed to every other joined clients ( including himself ) in a a green-coloured text
### if that user disconnects, his disconnecting message is displayed to every other joined clients in a red-coloured text